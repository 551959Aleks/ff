<?php
		$subject = 'Заявка с сайта '.$_SERVER['HTTP_HOST'].' из нижней формы';

        $main_url = $_SERVER['HTTP_HOST'];
        $user_ip = $_SERVER['REMOTE_ADDR'];

		$message = '
		<html>
			<body>';
		$message .= '
				<b>Адрес сайта: </b> '.$main_url.'<br><br>
                <b>Тема: </b> '.$subject.'<br>
                <b>IP адрес клиента: </b> '.$user_ip.'<br>
				<b>Имя: </b> '.$_POST[Name2].'<br>
				<b>Телефон: </b> '.$_POST[Phone2];
		$message .= '
			</body>
		</html>';


        $to  = 'okpotolok96@gmail.com';
        

		$headers  = "Content-type: text/html; charset=utf-8 \r\n";
		$headers .= "From: <noreply@$main_url>\r\n";


		mail($to, $subject, $message, $headers);
?>