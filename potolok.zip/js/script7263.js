jQuery.noConflict();
jQuery( window ).on( 'load', function($) {
  "use strict";
jQuery( '#loader-wrapper' ).fadeOut();




let squareCost = 400; //цена за кв\м
let lampCost = 250; //цена за лампу
let pipeCost = 150; //за трубу
// let cornerCost = 50; //за угол

let sq, lmp, cor, pip;

const input = document.querySelectorAll('.modal_form input');
const factura = document.querySelectorAll('.factura input');
let totalPr = document.getElementById('total-pr');
var facturaVal;

function collect(){

  function validateCheck() {
    for (var i = 0; i < factura.length; i++) {
        if (factura[i].checked) {
        facturaVal = factura[i].value;
      }
    }
  }
  validateCheck();

  for (var i = 0; i < input.length; i++) {
        if (input[i].id == 'square') {
            sq = parseInt(input[i].value * squareCost);
        }

        if (input[i].id == 'light') {
            lmp = parseInt(input[i].value * lampCost);
        }

        // if (input[i].id == 'corners') {
        //     cor = parseInt(input[i].value * cornerCost);
        // }

        if (input[i].id == 'pipe') {
            pip = parseInt(input[i].value * pipeCost);
        }

        if(typeof sq == "undefined"){
          sq = 0;
        }
        else if(typeof lmp == "undefined"){
          lmp = 0;
        }
        if(typeof cor == "undefined"){
          cor = 0;
        }
        if(typeof pip == "undefined"){
          pip = 0;
        }
        if(totalPr){
          totalPr.textContent = delim(sq + lmp  + pip);
        }
        
  }
}
collect();

input.forEach(function(el, index){
  el.addEventListener('keyup', function(){
    collect();
  });
});

factura.forEach(function(el, index){
  el.addEventListener('click', function(){
    collect();
  });
});

function delim(st){
  return parseInt(st).toString().replace(/(\d)(?=(\d\d\d)+([^\d]|$))/g, '$1 ');
}

});