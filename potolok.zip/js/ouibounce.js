(function (f, d) {
    "function" === typeof define && define.amd ? define(d) : "object" === typeof exports ? module.exports = d(require, exports, module) : f.ouibounce = d()
})(this, function (f, d, C) {
    return function (d, f) {
        function g(a, b) {
            return "undefined" === typeof a ? b : a
        }

        function m(a) {
            a *= 864E5;
            var b = new Date;
            b.setTime(b.getTime() + a);
            return "; expires=" + b.toUTCString()
        }

        function n(a) {
            a.clientY > y || (e = setTimeout(h, p))
        }

        function q() {
            e && (clearTimeout(e), e = null)
        }

        function r(a) {
            !t && a.metaKey && 76 === a.keyCode && (t = !0, e = setTimeout(h, p))
        }

        function k() {
            for (var a =
                    l, b = document.cookie.split("; "), d = {}, c = b.length - 1; 0 <= c; c--) {
                var e = b[c].split("=");
                d[e[0]] = e[1]
            }
            return "true" === d[a] && !z
        }

        function h() {
            k() || (d && $.magnificPopup.open({
                items: {
                    src: "#get-gift"
                },
                removalDelay: 2E3,
                midClick: !0
            }), A(), u())
        }

        function u(a) {
            a = a || {};
            "undefined" !== typeof a.cookieExpire && (v = m(a.cookieExpire));
            !0 === a.sitewide && (w = ";path=/");
            "undefined" !== typeof a.cookieDomain && (x = ";domain=" + a.cookieDomain);
            "undefined" !== typeof a.cookieName && (l = a.cookieName);
            document.cookie = l + "=true" + v + x + w;
            c.removeEventListener("mouseleave",
                n);
            c.removeEventListener("mouseenter", q);
            c.removeEventListener("keydown", r)
        }
        var b = f || {},
            z = b.aggressive || !1,
            y = g(b.sensitivity, 20),
            B = g(b.timer, 1E3),
            p = g(b.delay, 0),
            A = b.callback || function () {},
            v = m(b.cookieExpire) || "",
            x = b.cookieDomain ? ";domain=" + b.cookieDomain : "",
            l = b.cookieName ? b.cookieName : "viewedOuibounceModal",
            w = !0 === b.sitewide ? ";path=/" : "",
            e = null,
            c = document.documentElement;
        setTimeout(function () {
            k() || (c.addEventListener("mouseleave", n), c.addEventListener("mouseenter", q), c.addEventListener("keydown",
                r))
        }, B);
        var t = !1;
        return {
            fire: h,
            disable: u,
            isDisabled: k
        }
    }
});