<?php
		$subject = 'Заявка с сайта '.$_SERVER['HTTP_HOST'].' из первой формы';

		$main_url = $_SERVER['HTTP_HOST'];
		$user_ip = $_SERVER['REMOTE_ADDR'];

		$message = '
		<html>
			<body>';
		$message .= '
				<b>Адрес сайта: </b> '.$main_url.'<br><br>
				<b>Тема: </b> '.$subject.'<br>
				<b>IP адрес клиента: </b> '.$user_ip.'<br>
				<b>Имя: </b> '.$_POST[Name].'<br>
				<b>Телефон: </b> '.$_POST[Phone];
		$message .= '
			</body>
		</html>';


		$to  = 'eremin.m2.marketing@yandex.ru';

		$headers  = "Content-type: text/html; charset=utf-8 \r\n";
		$headers .= "From: <noreply@$main_url>\r\n";


		mail($to, $subject, $message, $headers);
?>