$(document).ready(function () {
	$("#form_calc").submit(function(){
		var params = $(this).serialize();
		$.ajax({
			type: 'POST',
			url: 'form.php',
			data: params,
			success: function(data){
				$('form')[0].reset();
				alert('Мы получили Вашу заявку. Ожидайте нашего звонка.');
			},
			error: function(data){
				$(".js-rule-error-req").modal('show');
			}
		});
		return false;
	});

	$("#form_calc").submit(function(){
		var params = $(this).serialize();
		$.ajax({
			type: 'POST',
			url: 'form2.php',
			data: params,
			success: function(data){
				$('#form2')[0].reset();
				alert('Мы получили Вашу заявку. Ожидайте нашего звонка.');
			},
			error: function(data){
				$(".js-rule-error-req").modal('show');
			}
		});
		return false;
	});

});